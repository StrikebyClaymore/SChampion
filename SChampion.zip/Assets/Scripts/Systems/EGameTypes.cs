﻿namespace Systems
{
    public enum EGameTypes
    {
        Football = 0,
        Basketball = 1,
        Tennis = 2,
    }
}