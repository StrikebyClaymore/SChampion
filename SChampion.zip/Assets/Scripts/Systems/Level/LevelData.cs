﻿using System;
using System.Collections.Generic;

namespace Systems
{
    [Serializable]
    public class LevelData
    {
        public List<LevelWave> Waves;
    }
}