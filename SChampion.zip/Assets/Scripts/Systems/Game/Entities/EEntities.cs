﻿namespace Systems.Game.Entities
{
    public enum EEntities
    {
        Ball = 0,
        Obstacle = 1,
        Bonus = 2,
        Star = 3,
        Finish = 4,
    }
}