﻿namespace Systems
{
    public enum ERecordPlace
    {
        First = 0,
        Second = 1,
        Third = 2,
    }
}