using UnityEngine;
using UnityEngine.UI;

namespace UI.Components
{
    public class CustomButton : MonoBehaviour
    {
        [SerializeField] private Button _button;
    }
}
