﻿namespace UI
{
    public enum EColorPalette
    {
        Green = 0,
        Yellow = 1,
    }
}